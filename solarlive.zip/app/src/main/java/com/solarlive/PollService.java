package com.solarlive;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.net.DhcpInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Keeps reading the inverter while the app is closed. It saves a 24 hour
 * history for the graph, counts energy for the current day, and posts
 * notifications when the battery is full or low.
 */
public class PollService extends Service {

    /** Receives each new reading while the app is on screen. */
    public interface Listener {
        void onJson(String json);
    }

    static final String HINT_IP = "192.168.1.114";
    private static final String CH_STATUS = "status";
    private static final String CH_ALERT = "alerts";
    private static final int ID_STATUS = 1;
    private static final long SAMPLE_MS = 30_000L;
    private static final long KEEP_SECONDS = 24L * 3600L;

    static volatile Listener listener;
    static volatile String latestJson;
    static volatile Solarman.Dongle manual;

    private static final Object HIST_LOCK = new Object();
    /** Each entry: time (epoch seconds), solar W, load W, battery %, battery W (positive = discharging). */
    private static final List<double[]> HISTORY = new ArrayList<>();

    private SharedPreferences prefs;
    private NotificationManager nm;
    private PowerManager.WakeLock cpuLock;
    private WifiManager.WifiLock wifiLock;
    private WifiManager.MulticastLock multicastLock;
    private volatile boolean running;
    private Thread worker;
    private File historyFile;

    // Energy counted by this app for the current day, in watt hours
    private String dayKey = "";
    private double whPv;
    private double whLoad;
    private double whCharge;
    private double whDischarge;
    private long trackedSince;
    private long lastTick;
    private long lastSample;
    private long lastSave;
    private long lastRewrite;

    private boolean firstReading = true;
    private boolean fullAlerted;
    private boolean lowAlerted;

    // ------------------------------------------------------------------
    // Service lifecycle
    // ------------------------------------------------------------------

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        prefs = getSharedPreferences("solar", Context.MODE_PRIVATE);
        nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        historyFile = new File(getFilesDir(), "history.csv");

        if (nm != null) {
            nm.createNotificationChannel(new NotificationChannel(CH_STATUS, "Monitoring", NotificationManager.IMPORTANCE_LOW));
            nm.createNotificationChannel(new NotificationChannel(CH_ALERT, "Battery alerts", NotificationManager.IMPORTANCE_HIGH));
        }
        Notification n = statusNotification("Starting...");
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(ID_STATUS, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
        } else {
            startForeground(ID_STATUS, n);
        }
        acquireLocks();
        loadHistory();
        loadDay();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (worker == null || !worker.isAlive()) {
            running = true;
            worker = new Thread(this::loop, "solar-poll");
            worker.start();
        }
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        running = false;
        if (worker != null) {
            worker.interrupt();
        }
        saveDay();
        releaseLocks();
        super.onDestroy();
    }

    @SuppressWarnings("deprecation")
    private void acquireLocks() {
        try {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            if (pm != null) {
                cpuLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "solarlive:poll");
                cpuLock.setReferenceCounted(false);
                cpuLock.acquire();
            }
            WifiManager wm = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            if (wm != null) {
                wifiLock = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "solarlive:wifi");
                wifiLock.setReferenceCounted(false);
                wifiLock.acquire();
                multicastLock = wm.createMulticastLock("solarlive:multicast");
                multicastLock.setReferenceCounted(false);
                multicastLock.acquire();
            }
        } catch (Exception ignored) {
            // locks are a convenience, polling still works without them
        }
    }

    private void releaseLocks() {
        try {
            if (cpuLock != null && cpuLock.isHeld()) {
                cpuLock.release();
            }
            if (wifiLock != null && wifiLock.isHeld()) {
                wifiLock.release();
            }
            if (multicastLock != null && multicastLock.isHeld()) {
                multicastLock.release();
            }
        } catch (Exception ignored) {
            // already released
        }
    }

    // ------------------------------------------------------------------
    // Main loop
    // ------------------------------------------------------------------

    private void loop() {
        Solarman client = null;
        Solarman.Dongle dongle = null;
        int failures = 0;

        long savedSerial = prefs.getLong("serial", 0);
        String savedIp = prefs.getString("ip", "");
        if (savedSerial != 0 && !savedIp.isEmpty()) {
            dongle = new Solarman.Dongle(savedIp, savedSerial);
        }

        while (running) {
            try {
                Solarman.Dongle typed = manual;
                if (typed != null) {
                    manual = null;
                    dongle = typed;
                    if (client != null) {
                        client.close();
                        client = null;
                    }
                }
                if (dongle == null) {
                    publish(Inverter.statusJson("searching", null));
                    dongle = Solarman.discover(targets(), 4000);
                    if (dongle == null) {
                        continue;
                    }
                    prefs.edit().putString("ip", dongle.ip).putLong("serial", dongle.serial).apply();
                }
                if (client == null) {
                    client = new Solarman(dongle.ip, 8899, dongle.serial, 1);
                    client.connect();
                }

                Map<String, Double> values = Inverter.read(client);
                failures = 0;
                long now = System.currentTimeMillis();
                count(values, now);
                sample(values, now);
                alerts(values);
                publish(Inverter.toJson(values, mineJson()));
                WidgetProvider.pushReading(this, values, now);

                Thread.sleep(listener != null ? 2000 : 10000);
            } catch (InterruptedException e) {
                break;
            } catch (Exception e) {
                publish(Inverter.statusJson("error", String.valueOf(e.getMessage())));
                WidgetProvider.pushStatus(this, "Not connected", System.currentTimeMillis());
                if (client != null) {
                    client.close();
                    client = null;
                }
                if (++failures >= 2) {
                    dongle = null;      // the address may have changed, look again
                    failures = 0;
                }
                lastTick = 0;           // do not count the gap as energy
                try {
                    Thread.sleep(3000);
                } catch (InterruptedException ie) {
                    break;
                }
            }
        }
        if (client != null) {
            client.close();
        }
    }

    private void publish(String json) {
        latestJson = json;
        Listener l = listener;
        if (l != null) {
            l.onJson(json);
        }
    }

    @SuppressWarnings("deprecation")
    private List<String> targets() {
        List<String> t = new ArrayList<>();
        t.add("255.255.255.255");
        try {
            WifiManager wm = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            DhcpInfo d = wm == null ? null : wm.getDhcpInfo();
            if (d != null && d.ipAddress != 0) {
                int bc = (d.ipAddress & d.netmask) | ~d.netmask;
                t.add((bc & 0xFF) + "." + ((bc >> 8) & 0xFF) + "." + ((bc >> 16) & 0xFF) + "." + ((bc >> 24) & 0xFF));
            }
        } catch (Exception ignored) {
            // fall back to the plain broadcast
        }
        String saved = prefs.getString("ip", "");
        if (!saved.isEmpty()) {
            t.add(saved);
        }
        t.add(HINT_IP);
        return t;
    }

    // ------------------------------------------------------------------
    // Energy counted by the app
    // ------------------------------------------------------------------

    private static String today() {
        return new SimpleDateFormat("yyyyMMdd", Locale.US).format(new Date());
    }

    private void loadDay() {
        dayKey = prefs.getString("day", "");
        if (dayKey.equals(today())) {
            whPv = prefs.getFloat("wh_pv", 0f);
            whLoad = prefs.getFloat("wh_load", 0f);
            whCharge = prefs.getFloat("wh_chg", 0f);
            whDischarge = prefs.getFloat("wh_dis", 0f);
            trackedSince = prefs.getLong("since", System.currentTimeMillis() / 1000);
        } else {
            resetDay();
        }
    }

    private void resetDay() {
        dayKey = today();
        whPv = 0;
        whLoad = 0;
        whCharge = 0;
        whDischarge = 0;
        trackedSince = System.currentTimeMillis() / 1000;
        saveDay();
    }

    private void saveDay() {
        prefs.edit()
            .putString("day", dayKey)
            .putFloat("wh_pv", (float) whPv)
            .putFloat("wh_load", (float) whLoad)
            .putFloat("wh_chg", (float) whCharge)
            .putFloat("wh_dis", (float) whDischarge)
            .putLong("since", trackedSince)
            .apply();
    }

    private void count(Map<String, Double> v, long now) {
        if (!dayKey.equals(today())) {
            resetDay();
            lastTick = 0;
        }
        if (lastTick > 0) {
            double hours = Math.min(now - lastTick, 30_000L) / 3_600_000.0;
            whPv += val(v, "pv_w") * hours;
            whLoad += val(v, "load_w") * hours;
            double b = val(v, "batt_w");
            if (b > 0) {
                whDischarge += b * hours;
            } else {
                whCharge += -b * hours;
            }
        }
        lastTick = now;
        if (now - lastSave > 30_000L) {
            lastSave = now;
            saveDay();
        }
    }

    private String mineJson() {
        return String.format(Locale.US,
            "\"mine_pv\":%.3f,\"mine_load\":%.3f,\"mine_chg\":%.3f,\"mine_dis\":%.3f,\"mine_since\":%d",
            whPv / 1000.0, whLoad / 1000.0, whCharge / 1000.0, whDischarge / 1000.0, trackedSince);
    }

    private static double val(Map<String, Double> v, String key) {
        Double d = v.get(key);
        return d == null ? 0 : d;
    }

    // ------------------------------------------------------------------
    // History
    // ------------------------------------------------------------------

    private void loadHistory() {
        long cutoff = System.currentTimeMillis() / 1000 - KEEP_SECONDS;
        synchronized (HIST_LOCK) {
            HISTORY.clear();
            if (!historyFile.exists()) {
                return;
            }
            try (BufferedReader r = new BufferedReader(new FileReader(historyFile))) {
                String line;
                while ((line = r.readLine()) != null) {
                    String[] p = line.split(",");
                    if (p.length < 5) {
                        continue;
                    }
                    try {
                        double[] row = new double[5];
                        for (int i = 0; i < 5; i++) {
                            row[i] = Double.parseDouble(p[i]);
                        }
                        if (row[0] >= cutoff) {
                            HISTORY.add(row);
                        }
                    } catch (NumberFormatException ignored) {
                        // skip a damaged line
                    }
                }
            } catch (IOException ignored) {
                // start with what was read
            }
        }
        rewriteHistory();
    }

    private void rewriteHistory() {
        synchronized (HIST_LOCK) {
            try (FileWriter w = new FileWriter(historyFile, false)) {
                for (double[] row : HISTORY) {
                    w.write(line(row));
                }
            } catch (IOException ignored) {
                // history is a convenience
            }
        }
        lastRewrite = System.currentTimeMillis();
    }

    private static String line(double[] r) {
        return String.format(Locale.US, "%.0f,%.0f,%.0f,%.0f,%.0f\n", r[0], r[1], r[2], r[3], r[4]);
    }

    private void sample(Map<String, Double> v, long now) {
        if (now - lastSample < SAMPLE_MS) {
            return;
        }
        lastSample = now;
        double[] row = {now / 1000.0, val(v, "pv_w"), val(v, "load_w"), val(v, "batt_soc"), val(v, "batt_w")};
        synchronized (HIST_LOCK) {
            HISTORY.add(row);
            long cutoff = now / 1000 - KEEP_SECONDS;
            while (!HISTORY.isEmpty() && HISTORY.get(0)[0] < cutoff) {
                HISTORY.remove(0);
            }
            try (FileWriter w = new FileWriter(historyFile, true)) {
                w.write(line(row));
            } catch (IOException ignored) {
                // history is a convenience
            }
        }
        if (now - lastRewrite > 3_600_000L) {
            rewriteHistory();
        }
        if (nm != null) {
            nm.notify(ID_STATUS, statusNotification(String.format(Locale.US,
                "Solar %,.0f W, load %,.0f W, battery %.0f%%", row[1], row[2], row[3])));
        }
    }

    /** History for the graph as [[time, solar W, load W, battery %, battery W], ...], thinned to about 400 points. */
    static String historyJson(int hours) {
        long cutoff = System.currentTimeMillis() / 1000 - hours * 3600L;
        List<double[]> rows = new ArrayList<>();
        synchronized (HIST_LOCK) {
            for (double[] r : HISTORY) {
                if (r[0] >= cutoff) {
                    rows.add(r);
                }
            }
        }
        int n = rows.size();
        int step = Math.max(1, (int) Math.ceil(n / 400.0));
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < n; i += step) {
            int end = Math.min(i + step, n);
            double[] sum = new double[5];
            for (int j = i; j < end; j++) {
                for (int k = 1; k < 5; k++) {
                    sum[k] += rows.get(j)[k];
                }
            }
            int c = end - i;
            if (i > 0) {
                sb.append(',');
            }
            sb.append(String.format(Locale.US, "[%.0f,%.0f,%.0f,%.0f,%.0f]",
                rows.get(end - 1)[0], sum[1] / c, sum[2] / c, sum[3] / c, sum[4] / c));
        }
        return sb.append(']').toString();
    }

    // ------------------------------------------------------------------
    // Notifications
    // ------------------------------------------------------------------

    private PendingIntent openApp() {
        Intent open = new Intent(this, MainActivity.class);
        return PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    private Notification statusNotification(String text) {
        return new Notification.Builder(this, CH_STATUS)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Solar Live")
            .setContentText(text)
            .setContentIntent(openApp())
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .build();
    }

    private void alert(int id, String title, String text) {
        if (nm == null) {
            return;
        }
        nm.notify(id, new Notification.Builder(this, CH_ALERT)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(text)
            .setContentIntent(openApp())
            .setAutoCancel(true)
            .build());
    }

    private void alerts(Map<String, Double> v) {
        Double socBox = v.get("batt_soc");
        if (socBox == null) {
            return;
        }
        double soc = socBox;
        int low = prefs.getInt("alert_low", 30);
        boolean full = prefs.getBoolean("alert_full", true);

        if (firstReading) {
            // do not alert for a state that was already true when monitoring started
            firstReading = false;
            fullAlerted = soc >= 100;
            lowAlerted = low > 0 && soc <= low;
            return;
        }
        if (full) {
            if (soc >= 100 && !fullAlerted) {
                fullAlerted = true;
                alert(2, "Battery full", String.format(Locale.US, "Solar is making %,.0f W and the house is using %,.0f W.",
                    val(v, "pv_w"), val(v, "load_w")));
            } else if (soc <= 95) {
                fullAlerted = false;
            }
        }
        if (low > 0) {
            if (soc <= low && !lowAlerted) {
                lowAlerted = true;
                alert(3, "Battery low", String.format(Locale.US, "Battery is at %.0f%%.", soc));
            } else if (soc >= low + 5) {
                lowAlerted = false;
            }
        }
    }
}
