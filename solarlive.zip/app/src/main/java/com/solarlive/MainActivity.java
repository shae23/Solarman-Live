package com.solarlive;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.net.DhcpInfo;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {

    /** Tried as well as the broadcast, in case the router blocks broadcasts. */
    private static final String HINT_IP = "192.168.1.114";

    private WebView web;
    private SharedPreferences prefs;
    private WifiManager.MulticastLock lock;
    private volatile int generation;
    private volatile Solarman.Dongle manual;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        prefs = getSharedPreferences("solar", MODE_PRIVATE);
        web = new WebView(this);
        web.setBackgroundColor(0xFF10141A);
        web.getSettings().setJavaScriptEnabled(true);
        web.addJavascriptInterface(new Bridge(), "Android");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    @Override
    protected void onResume() {
        super.onResume();
        WifiManager wm = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        if (wm != null) {
            lock = wm.createMulticastLock("solarlive");
            lock.setReferenceCounted(false);
            lock.acquire();
        }
        final int gen = ++generation;
        new Thread(() -> loop(gen), "solar-poll").start();
    }

    @Override
    protected void onPause() {
        super.onPause();
        generation++;
        if (lock != null && lock.isHeld()) {
            lock.release();
        }
    }

    // ------------------------------------------------------------------

    private void loop(int gen) {
        Solarman client = null;
        Solarman.Dongle dongle = null;
        int failures = 0;

        long savedSerial = prefs.getLong("serial", 0);
        String savedIp = prefs.getString("ip", "");
        if (savedSerial != 0 && !savedIp.isEmpty()) {
            dongle = new Solarman.Dongle(savedIp, savedSerial);
        }

        while (gen == generation) {
            try {
                Solarman.Dongle typed = manual;
                if (typed != null) {
                    manual = null;
                    dongle = typed;
                    if (client != null) {
                        client.close();
                        client = null;
                    }
                }
                if (dongle == null) {
                    push(Inverter.statusJson("searching", null));
                    dongle = Solarman.discover(targets(), 4000);
                    if (dongle == null) {
                        continue;
                    }
                    save(dongle);
                }
                if (client == null) {
                    client = new Solarman(dongle.ip, 8899, dongle.serial, 1);
                    client.connect();
                }
                push(Inverter.readJson(client));
                failures = 0;
                Thread.sleep(2000);
            } catch (InterruptedException e) {
                break;
            } catch (Exception e) {
                push(Inverter.statusJson("error", String.valueOf(e.getMessage())));
                if (client != null) {
                    client.close();
                    client = null;
                }
                if (++failures >= 2) {
                    dongle = null;      // the address may have changed, look again
                    failures = 0;
                }
                try {
                    Thread.sleep(3000);
                } catch (InterruptedException ie) {
                    break;
                }
            }
        }
        if (client != null) {
            client.close();
        }
    }

    private void push(String json) {
        final String js = "window.render&&window.render(" + json + ")";
        runOnUiThread(() -> {
            try {
                web.evaluateJavascript(js, null);
            } catch (Exception ignored) {
                // page is closing
            }
        });
    }

    private void save(Solarman.Dongle d) {
        prefs.edit().putString("ip", d.ip).putLong("serial", d.serial).apply();
    }

    @SuppressWarnings("deprecation")
    private List<String> targets() {
        List<String> t = new ArrayList<>();
        t.add("255.255.255.255");
        try {
            WifiManager wm = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            DhcpInfo d = wm == null ? null : wm.getDhcpInfo();
            if (d != null && d.ipAddress != 0) {
                int bc = (d.ipAddress & d.netmask) | ~d.netmask;
                t.add((bc & 0xFF) + "." + ((bc >> 8) & 0xFF) + "." + ((bc >> 16) & 0xFF) + "." + ((bc >> 24) & 0xFF));
            }
        } catch (Exception ignored) {
            // fall back to the plain broadcast
        }
        String saved = prefs.getString("ip", "");
        if (!saved.isEmpty()) {
            t.add(saved);
        }
        t.add(HINT_IP);
        return t;
    }

    /** Lets the page hand over a dongle address and serial typed by the user. */
    private final class Bridge {
        @JavascriptInterface
        public void setDongle(String ip, String serial) {
            try {
                long s = Long.parseLong(serial.trim());
                String address = ip.trim();
                if (address.isEmpty()) {
                    address = HINT_IP;
                }
                Solarman.Dongle d = new Solarman.Dongle(address, s);
                save(d);
                manual = d;
            } catch (Exception ignored) {
                // not a number, the page keeps showing the form
            }
        }
    }
}
