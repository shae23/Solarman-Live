package com.solarlive;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

public class MainActivity extends Activity {

    private WebView web;
    private SharedPreferences prefs;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        prefs = getSharedPreferences("solar", MODE_PRIVATE);
        web = new WebView(this);
        web.setBackgroundColor(0xFF0D0D0D);
        web.getSettings().setJavaScriptEnabled(true);
        web.addJavascriptInterface(new Bridge(), "Android");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");

        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[] {"android.permission.POST_NOTIFICATIONS"}, 1);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        startForegroundService(new Intent(this, PollService.class));
        PollService.listener = this::push;
        String last = PollService.latestJson;
        if (last != null) {
            push(last);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        PollService.listener = null;
    }

    private void push(String json) {
        final String js = "window.render&&window.render(" + json + ")";
        runOnUiThread(() -> {
            try {
                web.evaluateJavascript(js, null);
            } catch (Exception ignored) {
                // page is closing
            }
        });
    }

    /** Functions the page can call. */
    private final class Bridge {

        /** Dongle address and serial typed by the user. */
        @JavascriptInterface
        public void setDongle(String ip, String serial) {
            try {
                long s = Long.parseLong(serial.trim());
                String address = ip.trim();
                if (address.isEmpty()) {
                    address = PollService.HINT_IP;
                }
                prefs.edit().putString("ip", address).putLong("serial", s).apply();
                PollService.manual = new Solarman.Dongle(address, s);
            } catch (Exception ignored) {
                // not a number, the page keeps showing the form
            }
        }

        /** History for the graph. */
        @JavascriptInterface
        public String getHistory(int hours) {
            return PollService.historyJson(Math.max(1, Math.min(24, hours)));
        }

        /** Current alert settings as JSON. */
        @JavascriptInterface
        public String getSettings() {
            return "{\"low\":" + prefs.getInt("alert_low", 30)
                + ",\"full\":" + prefs.getBoolean("alert_full", true) + "}";
        }

        @JavascriptInterface
        public void setAlerts(int low, boolean full) {
            prefs.edit()
                .putInt("alert_low", Math.max(0, Math.min(99, low)))
                .putBoolean("alert_full", full)
                .apply();
        }

        /** Stops background monitoring. It starts again the next time the app is opened. */
        @JavascriptInterface
        public void stopMonitoring() {
            stopService(new Intent(MainActivity.this, PollService.class));
        }
    }
}
