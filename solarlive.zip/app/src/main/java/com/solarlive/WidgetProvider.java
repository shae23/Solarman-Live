package com.solarlive;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.widget.RemoteViews;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Map;

/** Home screen widget with solar, house load and battery. The background service feeds it. */
public class WidgetProvider extends AppWidgetProvider {

    private static long lastPush;
    private static long lastSave;

    @Override
    public void onUpdate(Context ctx, AppWidgetManager mgr, int[] ids) {
        // Show the last reading we saved, until the service sends a fresh one.
        SharedPreferences p = ctx.getSharedPreferences("solar", Context.MODE_PRIVATE);
        long ts = p.getLong("w_ts", 0);
        RemoteViews v;
        if (ts == 0) {
            v = views(ctx, "-", "-", "-", "Open the app to start");
        } else {
            String sub = battery(p.getFloat("w_batt", 0f)) + " " + new SimpleDateFormat("HH:mm", Locale.US).format(new Date(ts));
            v = views(ctx, watts(p.getFloat("w_pv", 0f)), watts(p.getFloat("w_load", 0f)),
                String.format(Locale.US, "%.0f%%", p.getFloat("w_soc", 0f)), "Last reading: " + sub);
        }
        mgr.updateAppWidget(ids, v);
    }

    /** Called by the service for every new reading. */
    static void pushReading(Context ctx, Map<String, Double> values, long now) {
        Double pv = values.get("pv_w");
        Double load = values.get("load_w");
        Double soc = values.get("batt_soc");
        Double batt = values.get("batt_w");
        double pvW = pv == null ? 0 : pv;
        double loadW = load == null ? 0 : load;
        double socP = soc == null ? 0 : soc;
        double battW = batt == null ? 0 : batt;

        if (now - lastSave > 30_000L) {
            lastSave = now;
            ctx.getSharedPreferences("solar", Context.MODE_PRIVATE).edit()
                .putFloat("w_pv", (float) pvW)
                .putFloat("w_load", (float) loadW)
                .putFloat("w_soc", (float) socP)
                .putFloat("w_batt", (float) battW)
                .putLong("w_ts", now)
                .apply();
        }
        if (now - lastPush < 5_000L) {
            return;
        }
        lastPush = now;
        push(ctx, views(ctx, watts(pvW), watts(loadW), String.format(Locale.US, "%.0f%%", socP),
            battery(battW) + " " + new SimpleDateFormat("HH:mm", Locale.US).format(new Date(now))));
    }

    /** Shown when the inverter cannot be read. */
    static void pushStatus(Context ctx, String text, long now) {
        if (now - lastPush < 5_000L) {
            return;
        }
        lastPush = now;
        push(ctx, views(ctx, "-", "-", "-", text));
    }

    private static void push(Context ctx, RemoteViews v) {
        try {
            AppWidgetManager mgr = AppWidgetManager.getInstance(ctx);
            int[] ids = mgr.getAppWidgetIds(new ComponentName(ctx, WidgetProvider.class));
            if (ids != null && ids.length > 0) {
                mgr.updateAppWidget(ids, v);
            }
        } catch (Exception ignored) {
            // the widget is optional
        }
    }

    private static RemoteViews views(Context ctx, String solar, String load, String batt, String sub) {
        RemoteViews v = new RemoteViews(ctx.getPackageName(), R.layout.widget);
        v.setTextViewText(R.id.w_solar, solar);
        v.setTextViewText(R.id.w_load, load);
        v.setTextViewText(R.id.w_batt, batt);
        v.setTextViewText(R.id.w_sub, sub);
        PendingIntent open = PendingIntent.getActivity(ctx, 1, new Intent(ctx, MainActivity.class),
            PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        v.setOnClickPendingIntent(R.id.widget_root, open);
        return v;
    }

    private static String watts(double w) {
        return String.format(Locale.US, "%,.0f W", w);
    }

    private static String battery(double battW) {
        if (battW > 20) {
            return String.format(Locale.US, "Battery discharging %,.0f W,", battW);
        }
        if (battW < -20) {
            return String.format(Locale.US, "Battery charging %,.0f W,", -battW);
        }
        return "Battery idle,";
    }
}
