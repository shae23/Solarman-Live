package com.solarlive;

import java.io.IOException;
import java.net.SocketTimeoutException;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/**
 * Register map and JSON output for SRNE hybrid inverters (HESP, HPB, ML, MLT
 * and similar). SRNE firmware rejects long reads, so the registers are read in
 * short blocks. A block the inverter refuses is skipped, and whatever else was
 * read is still shown.
 *
 * Addresses are from the public SRNE Modbus protocol as used by the
 * srne-solarman and esphome-srne-inverter projects.
 */
public final class Inverter {

    private Inverter() {
    }

    private static final class Block {
        final int start;
        final int count;
        final boolean required;

        Block(int start, int count, boolean required) {
            this.start = start;
            this.count = count;
            this.required = required;
        }
    }

    private static final Block[] BLOCKS = {
        new Block(0x0100, 15, true),    // battery SOC, voltage, current, PV1
        new Block(0x010F, 3, false),    // PV2 (single tracker models refuse this)
        new Block(0x0212, 14, true),    // grid voltage, output, load power
        new Block(0x022A, 13, false),   // second leg of a split phase output (load L2)
        new Block(0x023A, 1, false),    // grid power
        new Block(0xF02C, 18, false),   // today's energy counters
    };

    // Register addresses
    private static final int SOC = 0x0100;
    private static final int BATT_V = 0x0101;       // 0.1 V
    private static final int BATT_I = 0x0102;       // 0.1 A, signed, negative = discharging
    private static final int PV1_W = 0x0109;
    private static final int PV2_W = 0x0111;
    private static final int GRID_V = 0x0213;       // 0.1 V
    private static final int LOAD_W = 0x021B;       // load power, leg 1
    private static final int LOAD_L2_W = 0x0232;    // load power, leg 2 (split phase models)
    private static final int GRID_W = 0x023A;       // signed
    private static final int DAY_EXPORT = 0xF02C;   // 0.1 kWh
    private static final int DAY_PV = 0xF02F;       // 0.1 kWh
    private static final int DAY_LOAD = 0xF030;     // 0.1 kWh
    private static final int DAY_IMPORT = 0xF03D;   // 0.1 kWh

    /** Reads the inverter once and returns a JSON object for the dashboard page. */
    public static String readJson(Solarman dongle) throws IOException {
        Map<Integer, Integer> regs = new HashMap<>();
        IOException firstError = null;

        for (Block block : BLOCKS) {
            try {
                int[] values = dongle.readHolding(block.start, block.count);
                for (int i = 0; i < values.length; i++) {
                    regs.put(block.start + i, values[i]);
                }
            } catch (Solarman.ModbusException e) {
                if (firstError == null) {
                    firstError = e;
                }
            } catch (SocketTimeoutException e) {
                if (block.required) {
                    throw e;            // a required block timing out means the link is bad
                }
            }
        }

        if (!regs.containsKey(SOC) && !regs.containsKey(LOAD_W)) {
            throw firstError != null ? firstError : new IOException("Inverter returned no data");
        }

        StringBuilder sb = new StringBuilder("{\"status\":\"ok\",\"ts\":");
        sb.append(String.format(Locale.US, "%.3f", System.currentTimeMillis() / 1000.0));

        if (regs.containsKey(PV1_W) || regs.containsKey(PV2_W)) {
            int pv1 = regs.containsKey(PV1_W) ? regs.get(PV1_W) : 0;
            sb.append(",\"pv1_w\":").append(pv1);
            int pv2 = 0;
            if (regs.containsKey(PV2_W)) {
                pv2 = regs.get(PV2_W);
                sb.append(",\"pv2_w\":").append(pv2);
            }
            sb.append(",\"pv_w\":").append(pv1 + pv2);
        }
        if (regs.containsKey(LOAD_W)) {
            int l1 = regs.get(LOAD_W);
            if (regs.containsKey(LOAD_L2_W) && regs.get(LOAD_L2_W) > 0) {
                int l2 = regs.get(LOAD_L2_W);
                sb.append(",\"load_w\":").append(l1 + l2);
                sb.append(",\"load_l1_w\":").append(l1);
                sb.append(",\"load_l2_w\":").append(l2);
            } else {
                sb.append(",\"load_w\":").append(l1);
            }
        }
        if (regs.containsKey(GRID_W)) {
            sb.append(",\"grid_w\":").append(signed(regs.get(GRID_W)));
        }
        if (regs.containsKey(SOC)) {
            sb.append(",\"batt_soc\":").append(regs.get(SOC));
        }
        if (regs.containsKey(BATT_V)) {
            double volts = regs.get(BATT_V) * 0.1;
            sb.append(",\"batt_v\":").append(String.format(Locale.US, "%.2f", volts));
            if (regs.containsKey(BATT_I)) {
                double amps = signed(regs.get(BATT_I)) * 0.1;
                // The inverter reports charging as positive current. The page
                // wants discharging as positive watts.
                sb.append(",\"batt_w\":").append(Math.round(-(volts * amps)));
            }
        }
        if (regs.containsKey(GRID_V)) {
            sb.append(",\"grid_v\":").append(String.format(Locale.US, "%.1f", regs.get(GRID_V) * 0.1));
        }
        tenth(sb, regs, "day_pv", DAY_PV);
        tenth(sb, regs, "day_load", DAY_LOAD);
        tenth(sb, regs, "day_import", DAY_IMPORT);
        tenth(sb, regs, "day_export", DAY_EXPORT);
        return sb.append('}').toString();
    }

    private static int signed(int raw) {
        return raw > 32767 ? raw - 65536 : raw;
    }

    private static void tenth(StringBuilder sb, Map<Integer, Integer> regs, String name, int reg) {
        if (regs.containsKey(reg)) {
            sb.append(",\"").append(name).append("\":")
              .append(String.format(Locale.US, "%.1f", regs.get(reg) * 0.1));
        }
    }

    /** JSON for the "searching" and "error" screens. */
    public static String statusJson(String status, String message) {
        StringBuilder sb = new StringBuilder("{\"status\":\"").append(status).append("\"");
        if (message != null) {
            sb.append(",\"message\":\"");
            for (int i = 0; i < message.length() && i < 120; i++) {
                char c = message.charAt(i);
                if (c == '"' || c == '\\') {
                    sb.append('\\').append(c);
                } else if (c < 32) {
                    sb.append(' ');
                } else {
                    sb.append(c);
                }
            }
            sb.append('"');
        }
        return sb.append('}').toString();
    }
}
