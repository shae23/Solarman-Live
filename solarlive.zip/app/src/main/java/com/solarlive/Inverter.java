package com.solarlive;

import java.io.IOException;
import java.util.Locale;

/**
 * Register map and JSON output. The defaults are for Deye / Sunsynk single
 * phase hybrid inverters. Other models use different registers.
 */
public final class Inverter {

    private Inverter() {
    }

    /** Blocks to read: first register, how many. */
    private static final int[][] BLOCKS = {{70, 43}, {150, 42}};

    /** Name, register, scale, signed. */
    private static final Object[][] FIELDS = {
        {"pv1_w", 186, 1.0, false},
        {"pv2_w", 187, 1.0, false},
        {"load_w", 178, 1.0, false},
        {"grid_w", 169, 1.0, true},      // positive = importing from the grid
        {"batt_w", 190, 1.0, true},      // positive = discharging, negative = charging
        {"batt_soc", 184, 1.0, false},
        {"batt_v", 183, 0.01, false},
        {"grid_v", 150, 0.1, false},
        {"day_pv", 108, 0.1, false},
        {"day_load", 84, 0.1, false},
        {"day_import", 76, 0.1, false},
        {"day_export", 77, 0.1, false},
    };

    /** Reads the inverter once and returns a JSON object for the dashboard page. */
    public static String readJson(Solarman dongle) throws IOException {
        int[] regs = new int[256];
        boolean[] have = new boolean[256];
        for (int[] block : BLOCKS) {
            int[] values = dongle.readHolding(block[0], block[1]);
            for (int i = 0; i < values.length; i++) {
                regs[block[0] + i] = values[i];
                have[block[0] + i] = true;
            }
        }

        StringBuilder sb = new StringBuilder("{\"status\":\"ok\",\"ts\":");
        sb.append(String.format(Locale.US, "%.3f", System.currentTimeMillis() / 1000.0));
        int pv1 = 0;
        int pv2 = 0;
        for (Object[] field : FIELDS) {
            String name = (String) field[0];
            int reg = (Integer) field[1];
            double scale = (Double) field[2];
            boolean signed = (Boolean) field[3];
            if (!have[reg]) {
                continue;
            }
            int raw = regs[reg];
            if (signed && raw > 32767) {
                raw -= 65536;
            }
            sb.append(",\"").append(name).append("\":");
            if (scale == 1.0) {
                sb.append(raw);
            } else {
                sb.append(String.format(Locale.US, "%.2f", raw * scale));
            }
            if (name.equals("pv1_w")) {
                pv1 = raw;
            } else if (name.equals("pv2_w")) {
                pv2 = raw;
            }
        }
        sb.append(",\"pv_w\":").append(pv1 + pv2).append('}');
        return sb.toString();
    }

    /** JSON for the "searching" and "error" screens. */
    public static String statusJson(String status, String message) {
        StringBuilder sb = new StringBuilder("{\"status\":\"").append(status).append("\"");
        if (message != null) {
            sb.append(",\"message\":\"");
            for (int i = 0; i < message.length() && i < 120; i++) {
                char c = message.charAt(i);
                if (c == '"' || c == '\\') {
                    sb.append('\\').append(c);
                } else if (c < 32) {
                    sb.append(' ');
                } else {
                    sb.append(c);
                }
            }
            sb.append('"');
        }
        return sb.append('}').toString();
    }
}
