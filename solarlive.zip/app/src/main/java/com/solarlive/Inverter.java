package com.solarlive;

import java.io.IOException;
import java.net.SocketTimeoutException;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

/**
 * Register map and JSON output for SRNE hybrid inverters (HESP, HPB, ML, MLT
 * and similar). SRNE firmware rejects long reads, so the registers are read in
 * short blocks. A block the inverter refuses is skipped, and whatever else was
 * read is still shown.
 *
 * Addresses are from the public SRNE Modbus protocol as used by the
 * srne-solarman and esphome-srne-inverter projects.
 */
public final class Inverter {

    private Inverter() {
    }

    private static final class Block {
        final int start;
        final int count;
        final boolean required;

        Block(int start, int count, boolean required) {
            this.start = start;
            this.count = count;
            this.required = required;
        }
    }

    private static final Block[] BLOCKS = {
        new Block(0x0100, 15, true),    // battery, PV1, charge state
        new Block(0x010F, 3, false),    // PV2 (single tracker models refuse this)
        new Block(0x0212, 14, true),    // bus, grid, output, load
        new Block(0x0222, 1, false),    // inverter temperature
        new Block(0x022A, 13, false),   // second leg of a split phase output
        new Block(0x023A, 1, false),    // grid power
        new Block(0xF02C, 18, false),   // today's energy counters and most lifetime totals
        new Block(0xF046, 4, false),    // lifetime grid import
    };

    private static final int SOC = 0x0100;
    private static final int BATT_V = 0x0101;       // 0.1 V
    private static final int BATT_I = 0x0102;       // 0.1 A, signed, negative = discharging
    private static final int BATT_T = 0x0103;       // 0.1 C, signed
    private static final int PV1_V = 0x0107;
    private static final int PV1_A = 0x0108;
    private static final int PV1_W = 0x0109;
    private static final int CHARGE_STATE = 0x010B;
    private static final int CHARGE_W = 0x010E;
    private static final int PV2_V = 0x010F;
    private static final int PV2_A = 0x0110;
    private static final int PV2_W = 0x0111;
    private static final int BUS_V = 0x0212;
    private static final int GRID_V = 0x0213;
    private static final int GRID_HZ = 0x0215;      // 0.01 Hz
    private static final int OUT_V = 0x0216;
    private static final int OUT_HZ = 0x0218;
    private static final int LOAD_W = 0x021B;       // load power, leg 1
    private static final int LOAD_PCT = 0x021F;
    private static final int INV_T = 0x0222;
    private static final int LOAD_L2_W = 0x0232;    // load power, leg 2 (split phase models)
    private static final int GRID_W = 0x023A;       // signed
    private static final int DAY_EXPORT = 0xF02C;   // 0.1 kWh
    private static final int DAY_PV = 0xF02F;
    private static final int DAY_LOAD = 0xF030;
    private static final int DAY_IMPORT = 0xF03D;
    private static final int TOTAL_EXPORT = 0xF032; // 32 bit pairs, 0.1 kWh
    private static final int TOTAL_PV = 0xF038;
    private static final int TOTAL_LOAD = 0xF03A;
    private static final int TOTAL_IMPORT = 0xF048;

    /** Reads the inverter once. Keys are field names, values are in normal units (W, V, A, kWh, C). */
    public static Map<String, Double> read(Solarman dongle) throws IOException {
        Map<Integer, Integer> regs = new HashMap<>();
        IOException firstError = null;

        for (Block block : BLOCKS) {
            try {
                int[] values = dongle.readHolding(block.start, block.count);
                for (int i = 0; i < values.length; i++) {
                    regs.put(block.start + i, values[i]);
                }
            } catch (Solarman.ModbusException e) {
                if (firstError == null) {
                    firstError = e;
                }
            } catch (SocketTimeoutException e) {
                if (block.required) {
                    throw e;            // a required block timing out means the link is bad
                }
            }
        }

        if (!regs.containsKey(SOC) && !regs.containsKey(LOAD_W)) {
            throw firstError != null ? firstError : new IOException("Inverter returned no data");
        }

        Map<String, Double> out = new LinkedHashMap<>();

        // Solar
        Integer pv1 = regs.get(PV1_W);
        Integer pv2 = regs.get(PV2_W);
        if (pv1 != null || pv2 != null) {
            int a = pv1 == null ? 0 : pv1;
            int b = pv2 == null ? 0 : pv2;
            out.put("pv_w", (double) (a + b));
            if (pv1 != null) {
                out.put("pv1_w", (double) a);
            }
            if (pv2 != null) {
                out.put("pv2_w", (double) b);
            }
        }
        scaled(out, "pv1_v", regs.get(PV1_V), 0.1);
        scaled(out, "pv1_a", regs.get(PV1_A), 0.1);
        scaled(out, "pv2_v", regs.get(PV2_V), 0.1);
        scaled(out, "pv2_a", regs.get(PV2_A), 0.1);

        // Load
        Integer l1 = regs.get(LOAD_W);
        Integer l2 = regs.get(LOAD_L2_W);
        if (l1 != null) {
            if (l2 != null && l2 > 0) {
                out.put("load_w", (double) (l1 + l2));
                out.put("load_l1_w", (double) l1);
                out.put("load_l2_w", (double) l2);
            } else {
                out.put("load_w", (double) l1);
            }
        }
        scaled(out, "load_pct", regs.get(LOAD_PCT), 1.0);

        // Grid
        if (regs.containsKey(GRID_W)) {
            out.put("grid_w", (double) signed(regs.get(GRID_W)));
        }
        scaled(out, "grid_v", regs.get(GRID_V), 0.1);
        scaled(out, "grid_hz", regs.get(GRID_HZ), 0.01);
        scaled(out, "out_v", regs.get(OUT_V), 0.1);
        scaled(out, "out_hz", regs.get(OUT_HZ), 0.01);
        scaled(out, "bus_v", regs.get(BUS_V), 0.1);
        scaledSigned(out, "inv_temp_c", regs.get(INV_T), 0.1);

        // Battery
        scaled(out, "batt_soc", regs.get(SOC), 1.0);
        Integer rawV = regs.get(BATT_V);
        Integer rawI = regs.get(BATT_I);
        scaled(out, "batt_v", rawV, 0.1);
        scaledSigned(out, "batt_a", rawI, 0.1);      // positive = charging
        if (rawV != null && rawI != null) {
            double volts = rawV * 0.1;
            double amps = signed(rawI) * 0.1;
            // The page wants discharging as positive watts.
            out.put("batt_w", (double) Math.round(-(volts * amps)));
        }
        scaledSigned(out, "batt_temp_c", regs.get(BATT_T), 0.1);
        if (regs.containsKey(CHARGE_STATE)) {
            out.put("charge_state", (double) regs.get(CHARGE_STATE));
        }
        if (regs.containsKey(CHARGE_W)) {
            out.put("charge_w", (double) regs.get(CHARGE_W));
        }

        // Counters kept by the inverter
        scaled(out, "day_pv", regs.get(DAY_PV), 0.1);
        scaled(out, "day_load", regs.get(DAY_LOAD), 0.1);
        scaled(out, "day_import", regs.get(DAY_IMPORT), 0.1);
        scaled(out, "day_export", regs.get(DAY_EXPORT), 0.1);
        total(out, "total_pv", regs, TOTAL_PV);
        total(out, "total_load", regs, TOTAL_LOAD);
        total(out, "total_import", regs, TOTAL_IMPORT);
        total(out, "total_export", regs, TOTAL_EXPORT);
        return out;
    }

    /** Reads the inverter once and returns JSON for the dashboard page. */
    public static String readJson(Solarman dongle) throws IOException {
        return toJson(read(dongle), null);
    }

    /** Formats values as a JSON object. {@code extra} is spliced in as ready-made JSON members. */
    public static String toJson(Map<String, Double> values, String extra) {
        StringBuilder sb = new StringBuilder("{\"status\":\"ok\",\"ts\":");
        sb.append(String.format(Locale.US, "%.3f", System.currentTimeMillis() / 1000.0));
        for (Map.Entry<String, Double> e : values.entrySet()) {
            double v = e.getValue();
            sb.append(",\"").append(e.getKey()).append("\":");
            if (v == Math.rint(v) && Math.abs(v) < 1e12) {
                sb.append((long) v);
            } else {
                sb.append(String.format(Locale.US, "%.2f", v));
            }
        }
        if (extra != null && !extra.isEmpty()) {
            sb.append(',').append(extra);
        }
        return sb.append('}').toString();
    }

    private static int signed(int raw) {
        return raw > 32767 ? raw - 65536 : raw;
    }

    private static void scaled(Map<String, Double> out, String name, Integer raw, double scale) {
        if (raw != null) {
            out.put(name, raw * scale);
        }
    }

    private static void scaledSigned(Map<String, Double> out, String name, Integer raw, double scale) {
        if (raw != null) {
            out.put(name, signed(raw) * scale);
        }
    }

    /** Two registers joined high word first, in 0.1 kWh. Skipped if the result is not believable. */
    private static void total(Map<String, Double> out, String name, Map<Integer, Integer> regs, int reg) {
        Integer hi = regs.get(reg);
        Integer lo = regs.get(reg + 1);
        if (hi == null || lo == null) {
            return;
        }
        long value = ((long) hi << 16) | lo;
        if (value > 100_000_000L) {      // over ten million kWh, so the word order is wrong
            return;
        }
        out.put(name, value * 0.1);
    }

    /** JSON for the "searching" and "error" screens. */
    public static String statusJson(String status, String message) {
        StringBuilder sb = new StringBuilder("{\"status\":\"").append(status).append("\"");
        if (message != null) {
            sb.append(",\"message\":\"");
            for (int i = 0; i < message.length() && i < 120; i++) {
                char c = message.charAt(i);
                if (c == '"' || c == '\\') {
                    sb.append('\\').append(c);
                } else if (c < 32) {
                    sb.append(' ');
                } else {
                    sb.append(c);
                }
            }
            sb.append('"');
        }
        return sb.append('}').toString();
    }
}
