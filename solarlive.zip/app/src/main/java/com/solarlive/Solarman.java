package com.solarlive;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

/**
 * Minimal Solarman V5 client. Finds the Wi-Fi dongle on the local network and
 * reads Modbus holding registers from the inverter through it. No Android
 * classes are used here so it can be tested on a normal computer.
 */
public final class Solarman {

    /** A dongle found on the network. */
    public static final class Dongle {
        public final String ip;
        public final long serial;

        public Dongle(String ip, long serial) {
            this.ip = ip;
            this.serial = serial;
        }
    }

    private static final int TIMEOUT_MS = 4000;
    private static final Random RANDOM = new Random();

    private final String ip;
    private final int port;
    private final long serial;
    private final int slave;

    private Socket socket;
    private InputStream in;
    private OutputStream out;
    private int seq = -1;

    public Solarman(String ip, int port, long serial, int slave) {
        this.ip = ip;
        this.port = port;
        this.serial = serial;
        this.slave = slave;
    }

    // ------------------------------------------------------------------
    // Discovery
    // ------------------------------------------------------------------

    /**
     * Asks the network for Solarman dongles. The dongle answers a UDP probe on
     * port 48899 with "IP,MAC,SERIAL". Returns null if nothing answered.
     */
    public static Dongle discover(List<String> targets, int waitMs) throws IOException {
        return discover(targets, 48899, waitMs);
    }

    public static Dongle discover(List<String> targets, int udpPort, int waitMs) throws IOException {
        byte[] probe = "WIFIKIT-214028-READ".getBytes(StandardCharsets.US_ASCII);
        DatagramSocket sock = new DatagramSocket();
        try {
            sock.setBroadcast(true);
            sock.setSoTimeout(500);
            long end = System.currentTimeMillis() + waitMs;
            while (System.currentTimeMillis() < end) {
                for (String target : targets) {
                    try {
                        sock.send(new DatagramPacket(probe, probe.length, InetAddress.getByName(target), udpPort));
                    } catch (IOException ignored) {
                        // one bad target must not stop the others
                    }
                }
                try {
                    DatagramPacket reply = new DatagramPacket(new byte[1024], 1024);
                    sock.receive(reply);
                    String text = new String(reply.getData(), 0, reply.getLength(), StandardCharsets.US_ASCII).trim();
                    String[] parts = text.split(",");
                    if (parts.length >= 3 && parts[2].trim().matches("\\d+")) {
                        return new Dongle(parts[0].trim(), Long.parseLong(parts[2].trim()));
                    }
                } catch (SocketTimeoutException ignored) {
                    // no answer yet, send the probe again
                }
            }
            return null;
        } finally {
            sock.close();
        }
    }

    // ------------------------------------------------------------------
    // Connection
    // ------------------------------------------------------------------

    public synchronized void connect() throws IOException {
        close();
        Socket s = new Socket();
        s.connect(new InetSocketAddress(ip, port), TIMEOUT_MS);
        s.setSoTimeout(TIMEOUT_MS);
        s.setTcpNoDelay(true);
        socket = s;
        in = s.getInputStream();
        out = s.getOutputStream();
    }

    public synchronized void close() {
        if (socket != null) {
            try {
                socket.close();
            } catch (IOException ignored) {
                // nothing to do
            }
        }
        socket = null;
        in = null;
        out = null;
    }

    /** Reads {@code count} holding registers starting at {@code start}. */
    public synchronized int[] readHolding(int start, int count) throws IOException {
        if (socket == null) {
            connect();
        }
        int s = nextSeq();
        byte[] request = v5Encode(serial, s, modbusRequest(slave, 3, start, count));
        out.write(request);
        out.flush();
        byte[] modbus = awaitResponse(s);
        return parseHolding(modbus, slave, count);
    }

    private int nextSeq() {
        if (seq < 0) {
            seq = 1 + RANDOM.nextInt(254);
        } else {
            seq = (seq + 1) & 0xFF;
        }
        return seq;
    }

    // ------------------------------------------------------------------
    // Framing
    // ------------------------------------------------------------------

    /** Modbus RTU request: slave, function, start, count, CRC (low byte first). */
    static byte[] modbusRequest(int slave, int function, int start, int count) {
        byte[] f = new byte[8];
        f[0] = (byte) slave;
        f[1] = (byte) function;
        f[2] = (byte) (start >> 8);
        f[3] = (byte) start;
        f[4] = (byte) (count >> 8);
        f[5] = (byte) count;
        int crc = crc16(f, 6);
        f[6] = (byte) crc;
        f[7] = (byte) (crc >> 8);
        return f;
    }

    /** Wraps a Modbus frame in a V5 request frame for the data logging stick. */
    static byte[] v5Encode(long serial, int seq, byte[] modbus) {
        int payloadLen = 15 + modbus.length;
        byte[] f = new byte[11 + payloadLen + 2];
        int i = 0;
        f[i++] = (byte) 0xA5;
        f[i++] = (byte) payloadLen;
        f[i++] = (byte) (payloadLen >> 8);
        f[i++] = (byte) 0x10;           // control code 0x4510, low byte first
        f[i++] = (byte) 0x45;
        f[i++] = (byte) seq;            // sequence number, 2 bytes
        f[i++] = (byte) (seq >> 8);
        f[i++] = (byte) serial;         // logger serial, 4 bytes, low byte first
        f[i++] = (byte) (serial >> 8);
        f[i++] = (byte) (serial >> 16);
        f[i++] = (byte) (serial >> 24);
        f[i++] = 0x02;                  // frame type
        i += 14;                        // sensor type (2) and three 4 byte timers, all zero
        System.arraycopy(modbus, 0, f, i, modbus.length);
        f[f.length - 2] = (byte) checksum(f);
        f[f.length - 1] = 0x15;
        return f;
    }

    /** Sum of every byte except the first, the checksum and the last. */
    static int checksum(byte[] frame) {
        int sum = 0;
        for (int i = 1; i < frame.length - 2; i++) {
            sum += frame[i] & 0xFF;
        }
        return sum & 0xFF;
    }

    static int crc16(byte[] data, int length) {
        int crc = 0xFFFF;
        for (int i = 0; i < length; i++) {
            crc ^= data[i] & 0xFF;
            for (int bit = 0; bit < 8; bit++) {
                if ((crc & 1) != 0) {
                    crc = (crc >> 1) ^ 0xA001;
                } else {
                    crc >>= 1;
                }
            }
        }
        return crc & 0xFFFF;
    }

    // ------------------------------------------------------------------
    // Reading answers
    // ------------------------------------------------------------------

    private byte[] awaitResponse(int expectedSeq) throws IOException {
        long deadline = System.currentTimeMillis() + TIMEOUT_MS * 2L;
        while (System.currentTimeMillis() < deadline) {
            byte[] frame = readFrame();
            if (frame.length < 13) {
                continue;                                   // damaged frame
            }
            if ((frame[3] & 0xFF) != 0x10 || (frame[4] & 0xFF) != 0x15) {
                continue;                                   // keep-alive or other chatter
            }
            if ((frame[5] & 0xFF) != expectedSeq) {
                continue;                                   // answer to an older request
            }
            long replySerial = (frame[7] & 0xFFL) | ((frame[8] & 0xFFL) << 8)
                    | ((frame[9] & 0xFFL) << 16) | ((frame[10] & 0xFFL) << 24);
            if (replySerial != serial) {
                throw new IOException("Dongle serial number does not match");
            }
            if (frame[11] != 0x02) {
                throw new IOException("Unexpected frame type from dongle");
            }
            byte[] modbus = Arrays.copyOfRange(frame, 25, frame.length - 2);
            if (modbus.length < 5) {
                throw new IOException("Dongle returned no inverter data");
            }
            return modbus;
        }
        throw new SocketTimeoutException("No answer from dongle");
    }

    /** Reads one V5 frame from the stream. Returns an empty array if it was damaged. */
    private byte[] readFrame() throws IOException {
        int b;
        do {
            b = in.read();
            if (b < 0) {
                throw new IOException("Dongle closed the connection");
            }
        } while (b != 0xA5);
        byte[] lenBytes = new byte[2];
        readFully(lenBytes, 0, 2);
        int payloadLen = (lenBytes[0] & 0xFF) | ((lenBytes[1] & 0xFF) << 8);
        if (payloadLen > 1024) {
            return new byte[0];
        }
        byte[] frame = new byte[13 + payloadLen];
        frame[0] = (byte) 0xA5;
        frame[1] = lenBytes[0];
        frame[2] = lenBytes[1];
        readFully(frame, 3, frame.length - 3);
        if ((frame[frame.length - 1] & 0xFF) != 0x15
                || (frame[frame.length - 2] & 0xFF) != checksum(frame)) {
            return new byte[0];
        }
        return frame;
    }

    private void readFully(byte[] buf, int off, int len) throws IOException {
        int got = 0;
        while (got < len) {
            int n = in.read(buf, off + got, len - got);
            if (n < 0) {
                throw new IOException("Dongle closed the connection");
            }
            got += n;
        }
    }

    static int[] parseHolding(byte[] mb, int slave, int count) throws IOException {
        int n = mb.length;
        int calc = crc16(mb, n - 2);
        int got = (mb[n - 2] & 0xFF) | ((mb[n - 1] & 0xFF) << 8);
        if (calc != got) {
            throw new IOException("Bad Modbus checksum");
        }
        if ((mb[1] & 0x80) != 0) {
            throw new IOException("Inverter refused the request (code " + (mb[2] & 0xFF) + ")");
        }
        if ((mb[0] & 0xFF) != slave || mb[1] != 3) {
            throw new IOException("Unexpected Modbus reply");
        }
        int bytes = mb[2] & 0xFF;
        if (bytes != count * 2 || n != 3 + bytes + 2) {
            throw new IOException("Unexpected Modbus length");
        }
        int[] regs = new int[count];
        for (int i = 0; i < count; i++) {
            regs[i] = ((mb[3 + 2 * i] & 0xFF) << 8) | (mb[4 + 2 * i] & 0xFF);
        }
        return regs;
    }
}
